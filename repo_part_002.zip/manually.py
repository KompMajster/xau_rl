
import pandas as pd
f = pd.read_csv("data/XAUUSD_M5_features.csv", parse_dates=["time"]).sort_values("time")
print("FEAT:", len(f), f["time"].min(), "->", f["time"].max())