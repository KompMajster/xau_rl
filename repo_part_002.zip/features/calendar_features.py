# -*- coding: utf-8 -*-
"""
features/calendar_features.py
Kalendarz makro (Trading Economics) -> cechy 'time-to-event', 'post-event', dummies,
oraz 'surprise' (tylko w minucie publikacji). Bezpośredni request jest opcjonalny:
możesz też zasilać z lokalnego CSV (cache).

Dokumentacja TE Calendar API: https://docs.tradingeconomics.com/economic_calendar/  # cite: turn2search2
"""

from __future__ import annotations
import os, json
import pandas as pd, numpy as np
from pathlib import Path
from datetime import timezone

try:
    import requests  # type: ignore
except Exception:
    requests = None

DEFAULT_EVENTS = [
    "Non Farm Payrolls", "Unemployment Rate", "CPI", "Core CPI", "Core PCE",
    "ISM Manufacturing PMI", "ISM Services PMI", "FOMC Interest Rate Decision",
    "Fed Press Conference"
]

def fetch_te_calendar(api_key: str,
                      country: str = "United States",
                      start_iso: str = None,
                      end_iso: str = None) -> pd.DataFrame:
    """
    Pobiera kalendarz z Trading Economics. Jeśli requests brak -> podnieś błąd.
    Zwraca DataFrame z kolumnami: time_utc, country, event, actual, previous, forecast, importance
    """
    if requests is None:
        raise ImportError("Brak 'requests'. Użyj lokalnego CSV cache albo zainstaluj requests.")

    base = "https://api.tradingeconomics.com/calendar"
    params = {"country": country, "c": api_key}
    if start_iso and end_iso:
        base = f"{base}/{start_iso}/{end_iso}"

    r = requests.get(base, params=params, timeout=30)
    r.raise_for_status()
    data = r.json()
    rows = []
    for it in data:
        try:
            ts = pd.to_datetime(it.get('Date', it.get('DateUtc') or it.get('date')), utc=True)
            rows.append({
                'time_utc': ts,
                'country': it.get('Country'),
                'event': it.get('Event') or it.get('Category'),
                'actual': it.get('Actual') if it.get('Actual') not in (None, '') else np.nan,
                'previous': it.get('Previous') if it.get('Previous') not in (None, '') else np.nan,
                'forecast': it.get('Forecast') if it.get('Forecast') not in (None, '') else np.nan,
                'importance': it.get('Importance') or it.get('ImportanceValue') or 0
            })
        except Exception:
            continue
    df = pd.DataFrame(rows).dropna(subset=['time_utc','event']).sort_values('time_utc')
    return df

def load_calendar_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df['time_utc'] = pd.to_datetime(df['time_utc'], utc=True)
    return df.sort_values('time_utc')

def make_event_features(bars_csv: str,
                        calendar_df: pd.DataFrame,
                        events_whitelist: list[str] | None = None,
                        impact_threshold: int = 2) -> pd.DataFrame:
    """
    Tworzy cechy eventowe na indeksie M5 z bars_csv:
    - tt_event_min: minuty do najbliższego eventu (clipped np. do +/- 720)
    - post_event_min: minuty od ostatniego eventu
    - is_event_hi: 1 w minucie publikacji eventu o wysokim impakcie
    - surprise_{short}: (actual - forecast) tylko w minucie publikacji
    - one-hot per event (bazując na events_whitelist)

    'impact_threshold' – filtruje tylko eventy o wysokim impakcie.
    """
    bars = pd.read_csv(bars_csv, parse_dates=['time']).sort_values('time').reset_index(drop=True)
    bars['time'] = bars['time'].dt.tz_localize("UTC") if bars['time'].dt.tz is None else bars['time'].dt.tz_convert("UTC")

    ev = calendar_df.copy()
    if events_whitelist:
        ev = ev[ev['event'].isin(events_whitelist)].copy()

    # Map importance do int (0..3)
    def _imp(v):
        if v in (None, np.nan, ''): return 0
        try:
            return int(v)
        except Exception:
            return 0
    ev['imp_i'] = ev['importance'].apply(_imp)
    ev = ev[ev['imp_i'] >= impact_threshold]

    idx = pd.DatetimeIndex(bars['time'])
    # Najbliższy event >= now
    next_ts = np.array([ev['time_utc'][ev['time_utc'] >= t].min() if (ev['time_utc'] >= t).any() else pd.NaT for t in idx])
    prev_ts = np.array([ev['time_utc'][ev['time_utc'] <= t].max() if (ev['time_utc'] <= t).any() else pd.NaT for t in idx])

    tt_event_min = pd.Series(((pd.to_datetime(next_ts) - idx).astype('timedelta64[m]')).astype('float'), index=bars.index)
    post_event_min = pd.Series(((idx - pd.to_datetime(prev_ts)).astype('timedelta64[m]')).astype('float'), index=bars.index)
    tt_event_min = tt_event_min.clip(-720, 720).fillna(720.0)
    post_event_min = post_event_min.clip(-720, 720).fillna(720.0)

    # Flaga minuty publikacji (dokładne dopasowanie do 5-min slotu)
    pub_map = {pd.Timestamp(t, tz="UTC"): i for i, t in enumerate(ev['time_utc'])}
    is_event_hi = bars['time'].map(lambda t: 1 if t.floor('5min') in pub_map else 0).astype(int)

    # Surprise: tylko gdy jest exact minuta publikacji
    ev = ev.set_index(ev['time_utc'].dt.floor('5min'))
    ev_small = ev[['event','actual','forecast']].copy()
    ev_small['surprise'] = pd.to_numeric(ev_small['actual'], errors='coerce') - pd.to_numeric(ev_small['forecast'], errors='coerce')
    surprise = pd.Series(0.0, index=bars.index)
    surp_idx = bars['time'].dt.floor('5min')
    surprise.loc[is_event_hi == 1] = ev_small.reindex(surp_idx[is_event_hi == 1])['surprise'].values

    # One-hot po nazwie eventu (whitelist)
    features = {
        'tt_event_min': tt_event_min.values,
        'post_event_min': post_event_min.values,
        'is_event_hi': is_event_hi.values,
        'ev_surprise': surprise.fillna(0.0).values,
    }
    if events_whitelist:
        for name in events_whitelist:
            k = f"ev_{name.lower().replace(' ', '_').replace('/', '_')}"
            mask = (surp_idx.isin(ev_small.index)) & (ev_small.reindex(surp_idx)['event'] == name)
            features[k] = mask.astype(int).values

    out = pd.DataFrame(features, index=bars.index)
    out.insert(0, 'time', bars['time'].values)
    return out
