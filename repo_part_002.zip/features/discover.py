# -*- coding: utf-8 -*-
"""
features/discover.py
Selektor cech:
- IC (Spearman) cecha vs ret_{+1} (M5) na rolling oknach -> mediana IC, stabilność.
- (Opcjonalnie) ważność z prostego modelu (Lasso / GBDT), jeśli scikit-learn dostępny.
- Ograniczenie zmian: max +/- 'change_frac' względem poprzedniego features_spec.json.

Wejście: pełny plik features_csv (po zbudowaniu), config window, K, change_frac.
Wyjście: models/features_spec.json (lista kolumn + column price 'close_norm').
"""

from __future__ import annotations
import json
from pathlib import Path
import pandas as pd, numpy as np
from scipy.stats import spearmanr

try:
    from sklearn.linear_model import LassoCV  # type: ignore
    HAVE_SKL = True
except Exception:
    HAVE_SKL = False

BASE_COLS = ['time','open','high','low','close','tick_volume','spread']

def compute_targets(df: pd.DataFrame) -> pd.Series:
    ret1 = np.log(df['close']).diff().shift(-1)  # target = kolejna świeca
    return ret1

def rolling_ic(df_feat: pd.DataFrame, target: pd.Series, win: int = 5000) -> pd.Series:
    scores = {}
    valid_cols = [c for c in df_feat.columns if c not in BASE_COLS + ['close_log','close_norm']]
    # prosty IC na całym okresie (dla szybkości); wariant rolling można dodać później
    for c in valid_cols:
        a = df_feat[c].values
        b = target.values
        ok = np.isfinite(a) & np.isfinite(b)
        if ok.sum() < 500:  # min próbek
            scores[c] = 0.0
            continue
        rho, _ = spearmanr(a[ok], b[ok])
        scores[c] = 0.0 if (rho is None or np.isnan(rho)) else float(rho)
    return pd.Series(scores).sort_values(ascending=False)

def model_importance(df_feat: pd.DataFrame, target: pd.Series, top_n: int = 128) -> pd.Series:
    if not HAVE_SKL:
        return pd.Series(dtype=float)
    cols = [c for c in df_feat.columns if c not in BASE_COLS + ['close_log','close_norm']]
    X = df_feat[cols].replace([np.inf,-np.inf], np.nan).fillna(0.0).values
    y = target.replace([np.inf,-np.inf], np.nan).fillna(0.0).values
    if len(cols) == 0 or len(df_feat) < 1000:
        return pd.Series(dtype=float)
    model = LassoCV(cv=5, n_jobs=None, max_iter=10000).fit(X, y)
    imp = pd.Series(np.abs(model.coef_), index=cols)
    return imp.sort_values(ascending=False).head(top_n)

def select_topK(ic: pd.Series, imp: pd.Series | None, K: int = 96) -> list[str]:
    if imp is None or imp.empty:
        return list(ic.head(K).index)
    # fuzja rankingów (simple rank sum)
    ic_rank = ic.rank(ascending=False, method='dense')
    imp = imp.reindex(ic.index).fillna(0.0)
    imp_rank = imp.rank(ascending=False, method='dense')
    score = 1.0/ic_rank + 1.0/(imp_rank.replace(0, np.nan))
    return list(score.sort_values(ascending=False).head(K).index)

def apply_change_budget(prev_cols: list[str], new_cols: list[str], change_frac: float = 0.1) -> list[str]:
    if not prev_cols:
        return new_cols
    K = len(prev_cols)
    max_changes = max(1, int(round(K * change_frac)))
    keep = [c for c in new_cols if c in prev_cols]
    add  = [c for c in new_cols if c not in prev_cols][:max_changes]
    # Usuń najgorsze z poprzednich, żeby zwolnić miejsca
    drop_candidates = [c for c in prev_cols if c not in new_cols]
    drop = drop_candidates[:max_changes]
    # Final: (prev - drop) + add (z zachowaniem kolejności now_cols)
    result = [c for c in prev_cols if c not in drop]
    for c in new_cols:
        if c not in result and c in add:
            result.append(c)
    # Zabezpieczenie na dokładny rozmiar
    if len(result) > K:
        result = result[:K]
    elif len(result) < K:
        # dopełnij z 'keep' na wszelki wypadek
        for c in keep:
            if c not in result:
                result.append(c)
            if len(result) >= K:
                break
    return result

def write_features_spec(path_json: str, feat_cols: list[str], price_col: str = "close_norm") -> None:
    Path(path_json).parent.mkdir(parents=True, exist_ok=True)
    with open(path_json, "w", encoding="utf-8") as f:
        json.dump({"feature_columns": feat_cols, "price_column": price_col}, f, ensure_ascii=False, indent=2)

def main_discover(features_csv: str,
                  out_json: str = "models/features_spec.json",
                  topK: int = 96,
                  change_frac: float = 0.10):
    df = pd.read_csv(features_csv, parse_dates=['time']).sort_values('time').reset_index(drop=True)
    target = compute_targets(df)
    ic = rolling_ic(df, target)
    imp = model_importance(df, target, top_n=topK*2)  # opcjonalne
    proposal = select_topK(ic, imp, K=topK)

    prev = []
    p = Path(out_json)
    if p.exists():
        prev = json.loads(p.read_text(encoding='utf-8')).get("feature_columns", [])
        # nie bierzemy kolumn, których już fizycznie nie ma:
        prev = [c for c in prev if c in df.columns]

    final_cols = apply_change_budget(prev, proposal, change_frac=change_frac)
    write_features_spec(out_json, final_cols, "close_norm")
    print(f"[discover] Wrote {out_json} with {len(final_cols)} features.")