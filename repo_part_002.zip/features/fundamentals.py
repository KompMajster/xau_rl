# -*- coding: utf-8 -*-
"""
features/fundamentals.py
Fundamenty dla XAUUSD: realne stopy (DGS10 - T10YIE), USD index (np. FRED),
GPR (Caldara & Iacoviello), COT Gold (CFTC). As-of alignment i FFill -> M5.

Wymaga: pandas, numpy, (opcjonalnie) fredapi, requests, python-dotenv.
Źródła:
- FRED: DGS10, T10YIE (real 10y = DGS10 - T10YIE)      [St. Louis Fed]  # cite: turn2search20
- CFTC COT (COMEX Gold) weekly                          # cite: turn2search9
- GPR (Caldara & Iacoviello) monthly                    # cite: turn2search28
"""

from __future__ import annotations
import os, json
import pandas as pd, numpy as np
from datetime import datetime, timezone, timedelta
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

# ---------- Utils ----------

def _zscore(s: pd.Series, win: int = 252) -> pd.Series:
    mu = s.rolling(win, min_periods=max(10, win//10)).mean()
    sd = s.rolling(win, min_periods=max(10, win//10)).std().replace(0, np.nan)
    return (s - mu) / (sd + 1e-12)

def _ensure_dt_utc(s: pd.Series) -> pd.Series:
    if not isinstance(s.index, pd.DatetimeIndex):
        raise ValueError("Index must be DatetimeIndex")
    if s.index.tz is None:
        s.index = s.index.tz_localize("UTC")
    else:
        s.index = s.index.tz_convert("UTC")
    return s

def _asof_ffill_daily_to_m5(daily: pd.Series,
                            bars_m5: pd.DataFrame,
                            available_hour_utc: int = 23,
                            available_minute_utc: int = 59) -> pd.Series:
    """
    Dla wartości dziennych zakładamy, że 'stają się znane' o available_* UTC.
    Każda wartość jest użyta od (data, available_time) do kolejnej publikacji.
    To zachowuje konserwatywność (eliminuje look-ahead).
    """
    s = daily.copy()
    s = _ensure_dt_utc(s)
    # Utnij do zakresu świec
    s = s[(s.index <= bars_m5['time'].max())]
    if s.empty:
        return pd.Series(index=bars_m5.index, dtype=float)

    # Tworzymy serię znaczników as-of
    idx_asof = []
    vals = []
    for ts, val in s.items():
        ts_asof = pd.Timestamp(ts.date(), tz=timezone.utc) + timedelta(
            hours=available_hour_utc, minutes=available_minute_utc)
        idx_asof.append(ts_asof)
        vals.append(val)
    asof_series = pd.Series(vals, index=pd.DatetimeIndex(idx_asof, tz="UTC")).sort_index()

    # Reindeks do M5 time i ffill
    m5_idx = pd.DatetimeIndex(bars_m5['time']).tz_convert("UTC")
    out = asof_series.reindex(m5_idx, method="ffill")
    out.name = daily.name
    return out

# ---------- FRED ----------

def load_fred_series(series_id: str, api_key: str | None) -> pd.Series:
    """
    Ładuje serię z FRED (jeśli brak fredapi/klucza -> spodziewa się CSV w external/fred/{series_id}.csv)
    CSV format: DATE,VALUE
    """
    try:
        from fredapi import Fred  # type: ignore
    except Exception:
        Fred = None

    if Fred is not None and api_key:
        fred = Fred(api_key=api_key)
        s = fred.get_series(series_id)
        s = s.dropna().astype(float)
        s.index = pd.to_datetime(s.index, utc=True)
        s.name = series_id
        return s

    # Fallback: lokalny CSV
    p = Path("external/fred") / f"{series_id}.csv"
    if not p.exists():
        raise FileNotFoundError(f"Brak {p}. Zainstaluj fredapi lub umieść CSV.")
    df = pd.read_csv(p)
    df['DATE'] = pd.to_datetime(df['DATE'], utc=True)
    s = pd.Series(df.iloc[:, 1].astype(float).values, index=df['DATE'], name=series_id)
    return s

def build_real10y_and_usd(bars_m5: pd.DataFrame,
                          fred_key: str | None,
                          usd_series_id: str = "DTWEXBGS",
                          real_asof_hh: int = 23,
                          real_asof_mm: int = 59) -> pd.DataFrame:
    """
    Zwraca DataFrame z kolumnami: real10y, real10y_z, d_real10y, usd, usd_z
    - real10y = DGS10 - T10YIE (oba dzienne)  # cite: turn2search20
    - usd = indeks USD (np. DTWEXBGS z FRED)  # cite: turn2search25
    """
    dgs10 = load_fred_series("DGS10", fred_key)
    t10yie = load_fred_series("T10YIE", fred_key)
    real10y_daily = (dgs10 - t10yie).dropna()
    usd_daily = load_fred_series(usd_series_id, fred_key).dropna()

    real10y_m5 = _asof_ffill_daily_to_m5(real10y_daily, bars_m5, real_asof_hh, real_asof_mm)
    usd_m5     = _asof_ffill_daily_to_m5(usd_daily,     bars_m5, 23, 59)

    # pochodne
    real10y_z = _zscore(real10y_m5, 252*24*12//5)  # ~252 dni w M5 ≈ 12*24*252/5
    d_real10y = real10y_m5.diff()

    usd_z = _zscore(usd_m5, 252*24*12//5)

    out = pd.DataFrame({
        'real10y': real10y_m5.values,
        'real10y_z': real10y_z.values,
        'd_real10y': d_real10y.values,
        'usd': usd_m5.values,
        'usd_z': usd_z.values
    }, index=bars_m5.index)
    return out

# ---------- GPR ----------

def load_gpr_local_csv(path: str = "external/gpr/gpr.csv") -> pd.Series:
    """
    Oczekuje miesięcznego GPR z kolumnami ['date','gpr'], gdzie date to YYYY-MM-01 UTC.
    Oryginał i metodologia: Caldara & Iacoviello (AER 2022)                      # cite: turn2search28
    Pobrane dane umieść offline – unikamy look-ahead przez FFill miesięczny.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Brak {p}. Pobierz GPR i zapisz jako CSV.")
    df = pd.read_csv(p)
    df['date'] = pd.to_datetime(df['date'], utc=True)
    s = pd.Series(df['gpr'].astype(float).values, index=df['date'], name='gpr')
    return s

def gpr_to_m5(bars_m5: pd.DataFrame, gpr_monthly: pd.Series) -> pd.Series:
    gpr_monthly = _ensure_dt_utc(gpr_monthly)
    # As-of: konserwatywnie początek kolejnego miesiąca 00:00 UTC
    idx_asof = [pd.Timestamp(ts.year + (1 if ts.month==12 else 0),
                             1 if ts.month==12 else ts.month+1, 1, tz="UTC") for ts in gpr_monthly.index]
    s_asof = pd.Series(gpr_monthly.values, index=pd.DatetimeIndex(idx_asof, tz="UTC")).sort_index()
    m5_idx = pd.DatetimeIndex(bars_m5['time']).tz_convert('UTC')
    gpr_m5 = s_asof.reindex(m5_idx, method='ffill')
    gpr_m5.name = 'gpr'
    return gpr_m5

# ---------- COT (Gold) ----------

def load_cot_gold_local_csv(path: str = "external/cot_gold.csv") -> pd.DataFrame:
    """
    Oczekuje tygodniowego COT dla Gold (COMEX): kolumny ['date','mm_long','mm_short'] dla Managed Money.
    Dane z CFTC (Disaggregated report).                               # cite: turn2search9
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Brak {p}. Przygotuj eksport z CFTC i zapisz CSV.")
    df = pd.read_csv(p)
    df['date'] = pd.to_datetime(df['date'], utc=True)
    return df[['date','mm_long','mm_short']].sort_values('date')

def cot_to_m5(bars_m5: pd.DataFrame, cot_df: pd.DataFrame) -> pd.DataFrame:
    cot_df = cot_df.copy()
    cot_df['mm_net'] = cot_df['mm_long'].astype(float) - cot_df['mm_short'].astype(float)
    # Publikacja: piątek (as-of), dane na wtorek – używamy konserwatywnie od piątku 21:00 UTC
    asof_ts = cot_df['date'] + pd.Timedelta(days=3)  # wtorek -> piątek
    asof_ts = asof_ts.dt.tz_localize('UTC') + pd.Timedelta(hours=21)
    ser = pd.Series(cot_df['mm_net'].values, index=asof_ts, name='cot_mm_net').sort_index()

    m5_idx = pd.DatetimeIndex(bars_m5['time']).tz_convert("UTC")
    mm_net_m5 = ser.reindex(m5_idx, method='ffill')
    mm_net_z  = _zscore(mm_net_m5, 52)  # roczny tygodniowy zscore
    out = pd.DataFrame({'cot_mm_net': mm_net_m5.values, 'cot_mm_net_z': mm_net_z.values}, index=bars_m5.index)
    return out

# ---------- Orkiestracja ----------

def build_fundamentals_features(bars_csv: str,
                                fred_api_key: str | None,
                                gpr_csv: str | None = None,
                                cot_csv: str | None = None,
                                usd_series_id: str = "DTWEXBGS") -> pd.DataFrame:
    """
    Ładuje bars M5, dokleja fundamenty (real10y/usd/gpr/cot) jako cechy na indeksie świec M5.
    """
    bars = pd.read_csv(bars_csv, parse_dates=['time']).sort_values('time').reset_index(drop=True)
    core = build_real10y_and_usd(bars, fred_api_key, usd_series_id)

    cols = [core]
    if gpr_csv:
        gpr = load_gpr_local_csv(gpr_csv)
        gpr_m5 = gpr_to_m5(bars, gpr)
        cols.append(pd.DataFrame({'gpr': gpr_m5.values, 'gpr_z': _zscore(gpr_m5, 36).values}, index=core.index))
    if cot_csv:
        cot = load_cot_gold_local_csv(cot_csv)
        cols.append(cot_to_m5(bars, cot))

    out = pd.concat(cols, axis=1)
    out.insert(0, 'time', bars['time'].values)
    return out