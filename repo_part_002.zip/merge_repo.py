import os
import chardet

# === KONFIGURACJA ===
repo_path = r"C:\xau_rl"           # Ścieżka do folderu repozytorium
output_file = "merged_repo.txt"    # Nazwa wynikowego pliku

# Rozszerzenia plików do dołączenia
included_extensions = (".py", ".ipynb", ".txt", ".md", ".yaml", ".yml", '.ps1', '.log')

# Foldery, które mają być pominięte
excluded_dirs = {".venv", "__pycache__", ".git", ".idea", ".vscode", "build", "dist"}

# === FUNKCJA SCALANIA ===
with open(output_file, "w", encoding="utf-8") as outfile:
    for root, dirs, files in os.walk(repo_path):
        # Pomijaj foldery systemowe / techniczne
        dirs[:] = [d for d in dirs if d not in excluded_dirs]

        for filename in files:
            if filename.endswith(included_extensions):
                file_path = os.path.join(root, filename)
                try:
                    # Automatyczne wykrywanie kodowania
                    with open(file_path, "rb") as raw:
                        result = chardet.detect(raw.read(4096))
                        encoding = result["encoding"] or "utf-8"

                    with open(file_path, "r", encoding=encoding, errors="replace") as infile:
                        relative_path = os.path.relpath(file_path, repo_path)
                        outfile.write(f"\n\n=== FILE: {relative_path} ===\n\n")
                        outfile.write(infile.read())

                    print(f"✅ Dodano: {relative_path}")

                except Exception as e:
                    print(f"⚠️ Nie udało się odczytać pliku {filename}: {e}")

print(f"\n🎉 Gotowe! Wszystkie pliki scalono do: {output_file}")