﻿$ErrorActionPreference="Stop"
$REPO="C:\xau_rl"; $PY="$REPO\.venv\Scripts\python.exe"
$LOG="$REPO\logs\services\nightly_train.log"; $LOCK="$REPO\logs\services\nightly_train.lock"
New-Item -ItemType Directory -Force -Path (Split-Path $LOG) | Out-Null; Set-Location $REPO
if(-not (Test-Path $LOG) -or (Get-Item $LOG).Length -eq 0){
  "[$(Get-Date -Format o)] [nightly_train] bootstrap_alive" | Out-File -FilePath $LOG -Append -Encoding utf8
}
function Acquire-Lock { if(Test-Path $LOCK){$false}else{New-Item -ItemType File -Path $LOCK -Force|Out-Null;$true} }
function Release-Lock { if(Test-Path $LOCK){Remove-Item $LOCK -Force} }
function Run-Once {
  & $PY "rl\train_ppo.py" "--timesteps" "1500000" *>> $LOG
  & $PY "rl\evaluate.py" "--out_dir" "reports"    *>> $LOG
  & $PY "utils\make_report.py"                    *>> $LOG
  & $PY "ops\save_candidate.py"                   *>> $LOG
  & $PY "ops\promote_challenger.py"               *>> $LOG
}
function Seconds-To-Next-0030 {
  $now = Get-Date
  $target = [DateTime]::Today.AddHours(0).AddMinutes(30)
  if ($now -ge $target) { 
    $target = $target.AddDays(1) 
  }
  $diff = $target - $now
  return ([int]$diff.TotalSeconds)
}
while($true){
  Start-Sleep -Seconds (Seconds-To-Next-0030)
  $ts=Get-Date -Format o
  try{
    if(Acquire-Lock){
      "`n[$ts] [nightly_train] start" | Out-File -FilePath $LOG -Append -Encoding utf8
      Run-Once
      "`n[$(Get-Date -Format o)] [nightly_train] done"  | Out-File -FilePath $LOG -Append -Encoding utf8
      Release-Lock
    } else {
      "`n[$ts] [nightly_train] skipped (locked)" | Out-File -FilePath $LOG -Append -Encoding utf8
    }
  } catch {
    "[ERROR] $($_|Out-String)" | Out-File -FilePath $LOG -Append -Encoding utf8
    Release-Lock
  }
  Start-Sleep -Seconds (24*3600 - 60)
}
