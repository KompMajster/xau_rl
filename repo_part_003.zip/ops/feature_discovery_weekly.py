# ops/feature_discovery_weekly.py
# -*- coding: utf-8 -*-
"""
Feature Discovery (dziennie) dla XAUUSD M5:
- Czyta cechy z config.yaml -> files.features_csv,
- (Opcjonalnie) dołącza fundamenty i kalendarz (FRED/GPR/COT/Event),
- Tworzy lagi (--max_lag) w sposób blokowy (bez fragmentacji DataFrame),
- Rankuje cechy po Spearman do targetu 1-krok do przodu, z pominięciem
  kolumn stałych i zbyt krótkich (eliminuje ConstantInputWarning),
- Dywersyfikacja: kara za częste użycie + min. udział nowych (--change_frac),
- Zapisuje:
  * models/features_spec.json
  * models/features_spec_history.jsonl (append)
  * reports/feature_discovery_rank.csv
  * reports/feature_discovery_summary.txt
  * logs/feature_discovery.log
Uruchamiaj jako skrypt (nie jako moduł):
 .\\.venv\\Scripts\\python.exe ops\\feature_discovery_weekly.py --topK 96 --max_lag 3 --change_frac 0.10 --out models\\features_spec.json
"""

import argparse, os, json, traceback
from pathlib import Path
import pandas as pd
import numpy as np
import yaml
from datetime import datetime

# === ŚCIEŻKI ===
ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG = LOG_DIR / "feature_discovery.log"
HIST_PATH = ROOT / "models" / "features_spec_history.jsonl"
SUMMARY_PATH = ROOT / "reports" / "feature_discovery_summary.txt"
RANK_PATH = ROOT / "reports" / "feature_discovery_rank.csv"

# Parametry
MIN_NEW_RATIO = 0.20
HIST_WINDOW = 6
REPEAT_PENALTY = 0.90
MIN_OBS = 200
FRED_API_KEY_HARDCODED = "404d32dffe691fd6159eed5cceb44e80"

# === LOGOWANIE ===
def log(msg: str):
    ts = datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[{ts}] {msg}\n")

# === FUNKCJE ===
def load_cfg():
    with open(ROOT / "config.yaml", "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def read_features_csv(cfg):
    p = Path(cfg["files"]["features_csv"])
    if not p.exists():
        raise FileNotFoundError(f"features_csv not found: {p.as_posix()}")
    df = pd.read_csv(p, parse_dates=["time"])
    return df.sort_values("time").reset_index(drop=True)

def safe_merge_on_time(df_base: pd.DataFrame, df_right: pd.DataFrame, col_map: dict):
    if df_right is None or df_right.empty:
        return df_base
    r = df_right.copy()
    if "time" not in r.columns:
        raise ValueError("Right dataframe has no 'time'")
    r = (r.sort_values("time").drop_duplicates("time")
         .set_index("time").asfreq("1min").ffill()
         .reset_index().rename(columns=col_map))
    out = pd.merge_asof(
        df_base.sort_values("time"),
        r.sort_values("time"),
        on="time",
        direction="backward",
        tolerance=pd.Timedelta(minutes=10)
    )
    return out

def try_load_fred(series_id: str):
    if not series_id:
        return None
    try:
        from fredapi import Fred
        fred = Fred(api_key=FRED_API_KEY_HARDCODED)
        s = fred.get_series(series_id)
        df = s.to_frame(name=series_id).reset_index()
        df = df.rename(columns={"index": "time"})
        df["time"] = pd.to_datetime(df["time"], utc=True)
        return df
    except Exception as e:
        log(f"[warn] FRED api unavailable ({e}); trying CSV fallback")
        csv_p = ROOT / "external" / "fred" / f"{series_id}.csv"
        if csv_p.exists():
            df = pd.read_csv(csv_p)
            col_time = "time" if "time" in df.columns else ("date" if "date" in df.columns else None)
            if not col_time or "value" not in df.columns:
                raise RuntimeError(f"FRED CSV malformed: {csv_p.as_posix()}")
            df[col_time] = pd.to_datetime(df[col_time], utc=True)
            df = df.rename(columns={col_time: "time", "value": series_id})
            return df
    return None

def try_load_simple_csv(p: Path, time_col="time"):
    if not p or not Path(p).exists():
        return None
    df = pd.read_csv(p)
    if time_col not in df.columns:
        for c in ["date", "Date"]:
            if c in df.columns:
                time_col = c
                break
    if time_col not in df.columns:
        return None
    df[time_col] = pd.to_datetime(df[time_col], utc=True)
    return df.rename(columns={time_col: "time"})

def build_target(df: pd.DataFrame, price_col="close", horizon=1):
    return df[price_col].pct_change().shift(-horizon).rename("target_fwd1")

def add_lags(df: pd.DataFrame, cols: list, max_lag: int) -> pd.DataFrame:
    if max_lag <= 0 or not cols:
        return df
    lag_blocks = []
    for L in range(1, max_lag + 1):
        blk = df[cols].shift(L)
        blk.columns = [f"{c}_lag{L}" for c in cols]
        lag_blocks.append(blk)
    out = pd.concat([df] + lag_blocks, axis=1, copy=False)
    return out

def score_features(df: pd.DataFrame, feature_cols: list, target_col="target_fwd1"):
    scores = []
    y_full = df[target_col].astype(float)
    skipped_constant = []
    skipped_small = []
    for c in feature_cols:
        try:
            x_full = df[c].astype(float)
            ok = x_full.notna() & y_full.notna()
            n = int(ok.sum())
            if n < MIN_OBS:
                skipped_small.append(c)
                continue
            x = x_full[ok]
            y = y_full[ok]
            if x.nunique(dropna=True) <= 1 or y.nunique(dropna=True) <= 1:
                skipped_constant.append(c)
                continue
            rho = x.corr(y, method="spearman")
            if pd.notna(rho):
                scores.append((c, float(abs(rho))))
        except Exception:
            continue
    if skipped_small:
        log(f"[info] skipped_small_n<{MIN_OBS}: {len(skipped_small)} cols")
    if skipped_constant:
        log(f"[info] skipped_constant: {len(skipped_constant)} cols (e.g. {skipped_constant[:5]})")
    scores.sort(key=lambda t: t[1], reverse=True)
    return pd.DataFrame(scores, columns=["feature", "abs_spearman"])

def load_history(max_lines=HIST_WINDOW):
    if not HIST_PATH.exists():
        return []
    rows = []
    with open(HIST_PATH, "r", encoding="utf-8") as f:
        for line in f:
            try:
                rows.append(json.loads(line))
            except:
                pass
    return rows[-max_lines:] if rows else []

def save_history(entry: dict):
    HIST_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(HIST_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")

def jaccard(a: set, b: set) -> float:
    if not a and not b:
        return 1.0
    return len(a & b) / max(1, len(a | b))

def apply_repeat_penalty(rank_df: pd.DataFrame, hist_rows: list):
    if not hist_rows or rank_df.empty:
        return rank_df.copy()
    freq = {}
    for r in hist_rows:
        feats = r.get("feature_columns", [])
        for c in feats:
            freq[c] = freq.get(c, 0) + 1
    out = rank_df.copy()
    out["repeat_freq"] = out["feature"].map(lambda c: freq.get(c, 0))
    out["score_after_penalty"] = out["abs_spearman"] * (REPEAT_PENALTY ** out["repeat_freq"])
    out = out.sort_values("score_after_penalty", ascending=False).reset_index(drop=True)
    return out

def diversify_select(adjusted_rank: pd.DataFrame, prev_features: list, topK: int, min_new_ratio=MIN_NEW_RATIO):
    prev_set = set(prev_features or [])
    new_needed = int(np.ceil(topK * min_new_ratio))
    chosen = []
    for _, row in adjusted_rank.iterrows():
        f = row["feature"]
        if f not in prev_set and f not in chosen:
            chosen.append(f)
        if len([c for c in chosen if c not in prev_set]) >= new_needed:
            break
    if len(chosen) < topK:
        for _, row in adjusted_rank.iterrows():
            f = row["feature"]
            if f not in chosen:
                chosen.append(f)
            if len(chosen) >= topK:
                break
    return chosen[:topK]

# === MAIN ===
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--topK", type=int, default=96)
    ap.add_argument("--max_lag", type=int, default=3)
    ap.add_argument("--out", type=str, default="models/features_spec.json")
    ap.add_argument("--change_frac", type=float, default=None,
                    help="Minimalny udział nowych cech [0..1] względem poprzedniego wyboru")
    args = ap.parse_args()

    global MIN_NEW_RATIO
    if args.change_frac is not None:
        MIN_NEW_RATIO = float(np.clip(args.change_frac, 0.0, 1.0))

    try:
        log("feature_discovery bootstrap_alive")
        cfg = load_cfg()
        log("start")

        df = read_features_csv(cfg)
        price_col = "close_norm" if "close_norm" in df.columns else "close"
        df["target_fwd1"] = build_target(df, price_col=price_col)

        # Fundamenty i kalendarz
        try:
            fcfg = (cfg.get("fundamentals") or {})
            usd_id = fcfg.get("usd_series_id", None)
            fred_df = try_load_fred(usd_id) if usd_id else None
            if fred_df is not None:
                df = safe_merge_on_time(df, fred_df, {usd_id: f"fred_{usd_id}"})
                col = f"fred_{usd_id}"
                mu = df[col].rolling(5000, min_periods=100).mean()
                sd = df[col].rolling(5000, min_periods=100).std().replace(0, np.nan)
                df[col] = (df[col] - mu) / (sd + 1e-8)
            else:
                log("[info] FRED series not attached (no api/csv)")
        except Exception as e:
            log(f"[warn] fundamentals/calendar attach failed: {e}")

        base_cols = ["time", "open", "high", "low", "close", "tick_volume", "spread"]
        all_cols = [c for c in df.columns if c not in base_cols + ["target_fwd1"]]
        df = add_lags(df, all_cols, max_lag=args.max_lag)
        cand_cols = [c for c in df.columns if c not in base_cols + ["target_fwd1"]]

        rank = score_features(df, cand_cols, target_col="target_fwd1")
        if rank.empty:
            raise RuntimeError("Ranking pusty – brak danych do selekcji.")

        hist_rows = load_history(HIST_WINDOW)
        prev_feats = hist_rows[-1]["feature_columns"] if hist_rows else []
        rank_adj = apply_repeat_penalty(rank, hist_rows)

        out_rank = rank_adj.assign(prev_used=lambda x: x["feature"].isin(prev_feats))
        RANK_PATH.parent.mkdir(parents=True, exist_ok=True)
        out_rank.to_csv(RANK_PATH, index=False)

        topK = max(int(args.topK), 8)
        chosen = diversify_select(rank_adj, prev_feats, topK, MIN_NEW_RATIO)

        spec = {
            "feature_columns": chosen,
            "price_column": "close_norm" if "close_norm" in df.columns else "close",
            "generated_at": datetime.now().isoformat(timespec="seconds")
        }
        out_p = ROOT / args.out
        out_p.parent.mkdir(parents=True, exist_ok=True)
        out_p.write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")
        save_history({"ts": datetime.now().isoformat(timespec="seconds"), "feature_columns": chosen})

        prev_set = set(prev_feats or [])
        cur_set = set(chosen or [])
        jac = jaccard(prev_set, cur_set)
        chg = len(cur_set - prev_set)
        kept = len(cur_set & prev_set)
        SUMMARY_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(SUMMARY_PATH, "w", encoding="utf-8") as f:
            f.write("# Feature Discovery Summary\n")
            f.write(f"Generated at: {datetime.now().isoformat(timespec='seconds')}\n")
            f.write(f"TopK: {topK}\n")
            f.write(f"Prev size: {len(prev_set)}, Cur size: {len(cur_set)}\n")
            f.write(f"Jaccard(prev,cur): {jac:.3f}\n")
            f.write(f"Kept from prev: {kept}\n")
            f.write(f"New vs prev: {chg}\n")
            f.write(f"Min new ratio enforced: {MIN_NEW_RATIO:.2f}\n")

        log(f"saved spec -> {out_p.as_posix()}, rank -> {RANK_PATH.as_posix()}, summary -> {SUMMARY_PATH.as_posix()}")
        print("Feature discovery completed.")

    except Exception as e:
        log(f"[ERROR] {e}")
        log(traceback.format_exc())
        raise

if __name__ == "__main__":
    main()