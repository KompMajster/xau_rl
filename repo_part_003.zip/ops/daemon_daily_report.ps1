# Raport walidacyjny codziennie o 23:00 (czas lokalny)
$ErrorActionPreference = "Stop"
$REPO = "C:\xau_rl"
$PY = "C:\xau_rl\.venv\Scripts\python.exe"
$LOG = "C:\xau_rl\logs\services\daily_report.log"

New-Item -ItemType Directory -Force -Path (Split-Path $LOG) | Out-Null
Set-Location $REPO

function Run-Once {
  & $PY "rl\evaluate.py" "--out_dir" "reports" *>> $LOG
  & $PY "utils\make_report.py" *>> $LOG
}

function Seconds-To-Next-23 {
  $now = Get-Date
  $target = [DateTime]::Today.AddHours(23)
  if ($now -ge $target) { $target = $target.AddDays(1) }
  return int.TotalSeconds
}

# Poczekaj do 23:00, potem wykonuj raz dziennie
while ($true) {
  $sleep = Seconds-To-Next-23
  Start-Sleep -Seconds $sleep
  try {
    "`n[$(Get-Date -Format o)] [daily_report] start" | Out-File -FilePath $LOG -Append -Encoding utf8
    Run-Once
    "`n[$(Get-Date -Format o)] [daily_report] done" | Out-File -FilePath $LOG -Append -Encoding utf8
  } catch {
    "[ERROR] $($_ | Out-String)" | Out-File -FilePath $LOG -Append -Encoding utf8
  }
  "[$(Get-Date -Format o)] [bootstrap_alive]" | Out-File -FilePath $LOG -Append -Encoding utf8
  Start-Sleep -Seconds (24*3600 - 60)  # buffer
}