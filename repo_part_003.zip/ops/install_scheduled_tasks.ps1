# ops\install_scheduled_tasks.ps1
param(
  [string]$RepoRoot = "C:\xau_rl",
  [string]$PyExe    = "C:\xau_rl\.venv\Scripts\python.exe",
  [string]$UserName = "$env:USERNAME"
)

$ErrorActionPreference = "Stop"

# --- Katalog logów zadań ---
$TasksLogDir = Join-Path $RepoRoot "logs\tasks"
New-Item -ItemType Directory -Force -Path $TasksLogDir | Out-Null

# --- Funkcja: generowanie wrappera z logowaniem ---
function New-LogWrapper {
  param(
    [Parameter(Mandatory=$true)][string]$WrapperPath,
    [Parameter(Mandatory=$true)][string]$CommandLine,
    [Parameter(Mandatory=$true)][string]$LogPath
  )
  $content = @"
`$ErrorActionPreference = 'Continue'
`$ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
"[$ts] START $CommandLine" | Out-File -FilePath "$LogPath" -Append -Encoding utf8

try {
  & $CommandLine 1>> "$LogPath" 2>> "$LogPath"
} catch {
  "`$($_.Exception.Message)" | Out-File -FilePath "$LogPath" -Append -Encoding utf8
}

`$ts2 = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
"[$ts2] END $CommandLine" | Out-File -FilePath "$LogPath" -Append -Encoding utf8
"@
  $content | Set-Content -Path $WrapperPath -Encoding utf8 -Force
}

# --- 1) fetch + features co 10 min ---
$wrap1 = Join-Path $RepoRoot "ops\wr_fetch_features.ps1"
$log1  = Join-Path $TasksLogDir "fetch_features.log"
$cmd1  = "`"$PyExe`" `"$RepoRoot\fetch__mt5_data.py`" && `"$PyExe`" -m features.build_features"
New-LogWrapper -WrapperPath $wrap1 -CommandLine $cmd1 -LogPath $log1

schtasks /Create /TN "xau_fetch_features" `
  /TR "powershell -ExecutionPolicy Bypass -File `"$wrap1`"" `
  /SC MINUTE /MO 10 /RU $UserName /RL HIGHEST /F

# --- 2) Trading Economics cache raz dziennie 06:05 ---
$wrap2 = Join-Path $RepoRoot "ops\wr_te_calendar.ps1"
$log2  = Join-Path $TasksLogDir "te_calendar.log"
$cmd2  = "`"$PyExe`" `"$RepoRoot\save_te_calendar_cache.py`""
New-LogWrapper -WrapperPath $wrap2 -CommandLine $cmd2 -LogPath $log2

schtasks /Create /TN "xau_te_calendar" `
  /TR "powershell -ExecutionPolicy Bypass -File `"$wrap2`"" `
  /SC DAILY /ST 06:05 /RU $UserName /RL HIGHEST /F

# --- 3) mini-update co 6 godzin ---
$wrap3 = Join-Path $RepoRoot "ops\wr_mini_update.ps1"
$log3  = Join-Path $TasksLogDir "mini_update_6h.log"
$cmd3  = "`"$PyExe`" `"$RepoRoot\ops\mini_update_ppo.py`" --timesteps 300000 --train_days 120 --val_days 30"
New-LogWrapper -WrapperPath $wrap3 -CommandLine $cmd3 -LogPath $log3

schtasks /Create /TN "xau_mini_update" `
  /TR "powershell -ExecutionPolicy Bypass -File `"$wrap3`"" `
  /SC HOURLY /MO 6 /RU $UserName /RL HIGHEST /F

# --- 4) nightly train 23:10 ---
$wrap4 = Join-Path $RepoRoot "ops\wr_nightly_train.ps1"
$log4  = Join-Path $TasksLogDir "nightly_train.log"
$cmd4  = "`"$PyExe`" `"$RepoRoot\rl\train_ppo.py`" --timesteps 1500000"
New-LogWrapper -WrapperPath $wrap4 -CommandLine $cmd4 -LogPath $log4

schtasks /Create /TN "xau_nightly_train" `
  /TR "powershell -ExecutionPolicy Bypass -File `"$wrap4`"" `
  /SC DAILY /ST 23:10 /RU $UserName /RL HIGHEST /F

# --- 5) nightly raport/promocja 23:40 ---
$wrap5 = Join-Path $RepoRoot "ops\wr_nightly_report.ps1"
$log5  = Join-Path $TasksLogDir "nightly_report.log"
$cmd5  = "`"$PyExe`" `"$RepoRoot\rl\evaluate.py`" --out_dir reports && `"$PyExe`" `"$RepoRoot\utils\make_report.py`" && `"$PyExe`" `"$RepoRoot\ops\save_candidate.py`" && `"$PyExe`" `"$RepoRoot\ops\promote_challenger.py`""
New-LogWrapper -WrapperPath $wrap5 -CommandLine $cmd5 -LogPath $log5

schtasks /Create /TN "xau_nightly_report" `
  /TR "powershell -ExecutionPolicy Bypass -File `"$wrap5`"" `
  /SC DAILY /ST 23:40 /RU $UserName /RL HIGHEST /F

# --- 6) cleanup logów 03:15 ---
$wrap6 = Join-Path $RepoRoot "ops\wr_cleanup.ps1"
$log6  = Join-Path $TasksLogDir "cleanup.log"
$cmd6  = "powershell -ExecutionPolicy Bypass -File `"$RepoRoot\ops\cleanup_logs.ps1`" -RepoRoot `"$RepoRoot`" -CompressOldReports"

# wrapper dla cleanupu
$cleanupWrapper = @"
`$ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
"[$ts] START cleanup" | Out-File -FilePath "$log6" -Append -Encoding utf8
try { & $cmd6 1>> "$log6" 2>> "$log6" } catch { "`$($_.Exception.Message)" | Out-File -FilePath "$log6" -Append -Encoding utf8 }
`$ts2 = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
"[$ts2] END cleanup" | Out-File -FilePath "$log6" -Append -Encoding utf8
"@
$cleanupWrapper | Set-Content -Path $wrap6 -Encoding utf8 -Force

schtasks /Create /TN "xau_cleanup_logs" `
  /TR "powershell -ExecutionPolicy Bypass -File `"$wrap6`"" `
  /SC DAILY /ST 03:15 /RU $UserName /RL HIGHEST /F

Write-Host "Zadania zainstalowane. Logi zadan: $TasksLogDir"