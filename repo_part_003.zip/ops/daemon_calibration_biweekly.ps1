﻿$ErrorActionPreference="Stop"
$REPO="C:\xau_rl"; $PY="$REPO\.venv\Scripts\python.exe"
$LOG="$REPO\logs\services\calibration_3d.log"; $LOCK="$REPO\logs\services\calibration_3d.lock"
New-Item -ItemType Directory -Force -Path (Split-Path $LOG) | Out-Null; Set-Location $REPO
if(-not (Test-Path $LOG) -or (Get-Item $LOG).Length -eq 0){
  "[$(Get-Date -Format o)] [calibration] bootstrap_alive" | Out-File -FilePath $LOG -Append -Encoding utf8
}
function Acquire-Lock { if(Test-Path $LOCK){$false}else{New-Item -ItemType File -Path $LOCK -Force|Out-Null;$true} }
function Release-Lock { if(Test-Path $LOCK){Remove-Item $LOCK -Force} }
function Run-Once { & $PY "utils\calibration.py" "--apply" *>> $LOG }
function Seconds-To-Next-22 {
  $now = Get-Date
  $target = [DateTime]::Today.AddHours(22)
  if ($now -ge $target) { $target = $target.AddDays(1) }
  $diff = $target - $now
  return ([int]$diff.TotalSeconds)
}
while($true){
  Start-Sleep -Seconds (Seconds-To-Next-22)
  $ts=Get-Date -Format o
  try{
    if(Acquire-Lock){
      "`n[$ts] [calibration] start" | Out-File -FilePath $LOG -Append -Encoding utf8
      Run-Once
      "`n[$(Get-Date -Format o)] [calibration] done" | Out-File -FilePath $LOG -Append -Encoding utf8
      Release-Lock
    } else {
      "`n[$ts] [calibration] skipped (locked)" | Out-File -FilePath $LOG -Append -Encoding utf8
    }
  } catch {
    "[ERROR] $($_|Out-String)" | Out-File -FilePath $LOG -Append -Encoding utf8
    Release-Lock
  }
  Start-Sleep -Seconds (3*24*3600 - 60)
}
