﻿$ErrorActionPreference="Stop"
$REPO="C:\xau_rl"; $PY="$REPO\.venv\Scripts\python.exe"
$LOG="$REPO\logs\services\fetch_features.log"; $LOCK="$REPO\logs\services\fetch_features.lock"
New-Item -ItemType Directory -Force -Path (Split-Path $LOG) | Out-Null; Set-Location $REPO
if(-not (Test-Path $LOG) -or (Get-Item $LOG).Length -eq 0){
  "[$(Get-Date -Format o)] [fetch_features] bootstrap_alive" | Out-File -FilePath $LOG -Append -Encoding utf8
}
function Acquire-Lock { if(Test-Path $LOCK){$false}else{New-Item -ItemType File -Path $LOCK -Force|Out-Null;$true} }
function Release-Lock { if(Test-Path $LOCK){Remove-Item $LOCK -Force} }
function Run-Once {
  & $PY "fetch__mt5_data.py"         *>> $LOG
  & $PY "features\build_features.py" *>> $LOG
}
while($true){
  $ts=Get-Date -Format o
  try{
    if(Acquire-Lock){
      "`n[$ts] [fetch_features] start" | Out-File -FilePath $LOG -Append -Encoding utf8
      Run-Once
      "`n[$(Get-Date -Format o)] [fetch_features] done" | Out-File -FilePath $LOG -Append -Encoding utf8
      Release-Lock
    } else {
      "`n[$ts] [fetch_features] skipped (locked)" | Out-File -FilePath $LOG -Append -Encoding utf8
    }
  }catch{
    "[ERROR] $($_|Out-String)" | Out-File -FilePath $LOG -Append -Encoding utf8
    Release-Lock
  }
  Start-Sleep -Seconds 600
}
