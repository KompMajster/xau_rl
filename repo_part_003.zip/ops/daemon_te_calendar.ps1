﻿$ErrorActionPreference="Stop"
$REPO="C:\xau_rl"; $PY="$REPO\.venv\Scripts\python.exe"
$LOG="$REPO\logs\services\te_calendar.log"; $LOCK="$REPO\logs\services\te_calendar.lock"
New-Item -ItemType Directory -Force -Path (Split-Path $LOG) | Out-Null; Set-Location $REPO
if(-not (Test-Path $LOG) -or (Get-Item $LOG).Length -eq 0){
  "[$(Get-Date -Format o)] [te_calendar] bootstrap_alive" | Out-File -FilePath $LOG -Append -Encoding utf8
}
function Acquire-Lock { if(Test-Path $LOCK){$false}else{New-Item -ItemType File -Path $LOCK -Force|Out-Null;$true} }
function Release-Lock { if(Test-Path $LOCK){Remove-Item $LOCK -Force} }
function Run-Once {
  & $PY "save_te_calendar_cache.py" *>> $LOG
  & $PY "features\build_features.py" *>> $LOG
}
function Seconds-To-Next-0500 {
  $now    = Get-Date
  $target = [DateTime]::Today.AddHours(5)
  if ($now -ge $target) { $target = $target.AddDays(1) }
  $diff = $target - $now
  return [int]$diff.TotalSeconds
}
while($true){
  Start-Sleep -Seconds (Seconds-To-Next-0500)
  $ts=Get-Date -Format o
  try{
    if(Acquire-Lock){
      "`n[$ts] [te_calendar] start" | Out-File -FilePath $LOG -Append -Encoding utf8
      Run-Once
      "`n[$(Get-Date -Format o)] [te_calendar] done"  | Out-File -FilePath $LOG -Append -Encoding utf8
      Release-Lock
    } else {
      "`n[$ts] [te_calendar] skipped (locked)" | Out-File -FilePath $LOG -Append -Encoding utf8
    }
  } catch {
    "[ERROR] $($_|Out-String)" | Out-File -FilePath $LOG -Append -Encoding utf8
    Release-Lock
  }
  Start-Sleep -Seconds (24*3600 - 60)
}
