﻿$ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
"[] START cleanup" | Out-File -FilePath "C:\xau_rl\logs\tasks\cleanup.log" -Append -Encoding utf8
try { & powershell -ExecutionPolicy Bypass -File "C:\xau_rl\ops\cleanup_logs.ps1" -RepoRoot "C:\xau_rl" -CompressOldReports 1>> "C:\xau_rl\logs\tasks\cleanup.log" 2>> "C:\xau_rl\logs\tasks\cleanup.log" } catch { "$(.Exception.Message)" | Out-File -FilePath "C:\xau_rl\logs\tasks\cleanup.log" -Append -Encoding utf8 }
$ts2 = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
"[] END cleanup" | Out-File -FilePath "C:\xau_rl\logs\tasks\cleanup.log" -Append -Encoding utf8
