﻿# utils/calibration.py
# -*- coding: utf-8 -*-
import argparse, yaml, pandas as pd, numpy as np
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--apply', action='store_true', help='Nadpisz config.yaml sugerowanymi kosztami')
parser.add_argument('--ticks_csv', type=str, default=None, help='Ścieżka do CSV z tickami (domyślnie z config.yaml)')
parser.add_argument('--bars_csv', type=str, default=None, help='Ścieżka do CSV ze świecami (domyślnie z config.yaml)')
args = parser.parse_args()

cfg = yaml.safe_load(open('config.yaml','r',encoding='utf-8'))
TICKS = args.ticks_csv or cfg['files']['ticks_csv']
BARS  = args.bars_csv  or cfg['files']['bars_csv']

ticks = pd.read_csv(TICKS, parse_dates=['time'])
ticks['spread'] = ticks['ask'] - ticks['bid']
mid = (ticks['ask'] + ticks['bid']) / 2.0
dmid = mid.diff().abs()

spread_median = float(ticks['spread'].median())
spread_p95    = float(ticks['spread'].quantile(0.95))
bars = pd.read_csv(BARS, parse_dates=['time'])
bar_move_med = float(bars['close'].diff().abs().median())

# Slippage ~ median|Δmid| jako proporcja do mediany ruchu barowego (ucięta do sensownych widełek)
slippage_k = float(np.clip(dmid.median() / max(bar_move_med, 1e-12), 0.0, 0.5))

Path('reports').mkdir(parents=True, exist_ok=True)
Path('reports/costs_suggestion.yaml').write_text(
    yaml.safe_dump(
        {
            'spread_abs_median': round(spread_median, 5),
            'spread_abs_p95': round(spread_p95, 5),
            'slippage_k_suggested': round(slippage_k, 3),
        },
        allow_unicode=True, sort_keys=False
    ),
    encoding='utf-8'
)
print("Saved: reports/costs_suggestion.yaml")

if args.apply:
    cfg.setdefault('costs', {})
    cfg['costs']['spread_abs']   = round(spread_median, 5)
    cfg['costs']['slippage_k']   = round(slippage_k, 3)
    Path('config.yaml').write_text(yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False), encoding='utf-8')
    print("Applied suggestions to config.yaml")