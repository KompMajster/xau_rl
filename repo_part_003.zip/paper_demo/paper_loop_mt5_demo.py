﻿# -*- coding: utf-8 -*-
"""
Paper Trading Loop (MT5) – PPO Integration
✔ Dynamic feature mapping from features_spec.json
✔ Log missing features
✔ CSV with decision + trade params + retcode
"""

import MetaTrader5 as mt5
import pandas as pd
import numpy as np
import yaml
import time
import logging
import pickle
import json
from pathlib import Path
from datetime import time as dtime
from stable_baselines3 import PPO
from utils.mt5_health import ensure_mt5_ready

# === Konfiguracja ===
logging.basicConfig(filename='paper_demo/live_trading.log',
                    level=logging.INFO,
                    format='%(asctime)s %(levelname)s %(message)s')

cfg = yaml.safe_load(open('config.yaml', 'r', encoding='utf-8'))
SYMBOL = cfg['symbol']
WINDOW = int(cfg.get('window', 128))
MODEL_PATH = cfg['files']['model_path']
VECNORM_PATH = cfg.get('files', {}).get('vecnorm_path', 'models/vecnorm_xauusd_m5.pkl')
TF_MAP = {'M1': mt5.TIMEFRAME_M1, 'M5': mt5.TIMEFRAME_M5, 'M15': mt5.TIMEFRAME_M15}
TF_NAME = cfg.get('timeframe', 'M5')
TF = TF_MAP.get(TF_NAME, mt5.TIMEFRAME_M5)

MIN_EQUITY = float(cfg.get('env', {}).get('min_equity', 0.8))
TRADE_HOURS = cfg.get('env', {}).get('trade_hours_utc', None)
SLIPPAGE = 10
MAGIC = 123456

# === Funkcje pomocnicze ===
def in_trade_hours(ts):
    if not TRADE_HOURS or len(TRADE_HOURS) != 2:
        return True
    try:
        start_h, start_m = [int(x) for x in TRADE_HOURS[0].split(':')]
        end_h, end_m = [int(x) for x in TRADE_HOURS[1].split(':')]
        start = dtime(start_h, start_m)
        end = dtime(end_h, end_m)
        t = ts.to_pydatetime().time()
        if start <= end:
            return start <= t <= end
        return t >= start or t <= end
    except Exception:
        return True

def add_features_incremental(df):
    df = df.sort_values('time').reset_index(drop=True)
    df['ret1'] = np.log(df['close']).diff()
    df['ema10'] = df['close'].ewm(span=10).mean()
    df['ema50'] = df['close'].ewm(span=50).mean()
    df['ema200'] = df['close'].ewm(span=200).mean()
    d = df['close'].diff()
    up = d.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    down = (-d.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
    rs = up / (down + 1e-12)
    df['rsi14'] = 100 - (100 / (1 + rs))
    h, l, c = df['high'], df['low'], df['close']
    tr = np.maximum(h - l, np.maximum(abs(h - c.shift()), abs(l - c.shift())))
    df['atr14'] = tr.ewm(alpha=1/14, adjust=False).mean()
    ema_fast = df['close'].ewm(span=12, adjust=False).mean()
    ema_slow = df['close'].ewm(span=26, adjust=False).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=9, adjust=False).mean()
    df['macd'] = macd_line
    df['macd_signal'] = signal_line
    df['macd_hist'] = macd_line - signal_line
    ma = df['close'].rolling(20).mean()
    sd = df['close'].rolling(20).std()
    df['bb_ma'] = ma
    df['bb_up'] = ma + 2 * sd
    df['bb_lo'] = ma - 2 * sd
    df['bb_width'] = (df['bb_up'] - df['bb_lo']) / (ma.replace(0, np.nan).abs() + 1e-12)
    df['close_log'] = np.log(df['close'].clip(lower=1e-12))
    mu = df['close_log'].rolling(2000, min_periods=200).mean()
    s = df['close_log'].rolling(2000, min_periods=200).std().replace(0, np.nan)
    df['close_norm'] = (df['close_log'] - mu) / (s + 1e-8)
    return df.dropna().reset_index(drop=True)

def get_last_bars(symbol, timeframe, n):
    rates = mt5.copy_rates_from_pos(symbol, timeframe, 0, n)
    if rates is None or len(rates) < n:
        return None
    df = pd.DataFrame(rates)
    df['time'] = pd.to_datetime(df['time'], unit='s', utc=True)
    df.rename(columns={'real_volume': 'tick_volume'}, inplace=True)
    return df[['time', 'open', 'high', 'low', 'close', 'tick_volume', 'spread']]

def build_obs(df_feat, model_obs_dim):
    spec_path = Path("models/features_spec.json")
    if not spec_path.exists():
        raise RuntimeError("Brak pliku features_spec.json – uruchom feature discovery.")
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    feature_cols = spec.get("feature_columns", [])
    if not feature_cols:
        raise RuntimeError("Specyfikacja cech jest pusta.")

    tail = df_feat.tail(WINDOW)
    block = []
    matched = 0
    for col in feature_cols:
        if col in tail.columns:
            block.append(tail[col].to_numpy(dtype=np.float32))
            matched += 1
        else:
            block.append(np.zeros(WINDOW, dtype=np.float32))
    block = np.stack(block, axis=1)

    per_step = (model_obs_dim - 2) // WINDOW
    zero_filled = 0
    if block.shape[1] != per_step:
        logging.warning(f"Mismatch: model expects {per_step} features, spec has {block.shape[1]}. Adjusting.")
        if block.shape[1] < per_step:
            zero_filled = per_step - block.shape[1]
            pad = np.zeros((WINDOW, zero_filled), dtype=np.float32)
            block = np.concatenate([block, pad], axis=1)
        else:
            block = block[:, :per_step]
    flat = block.flatten()
    return np.concatenate([flat, np.array([0.0, 0.0], dtype=np.float32)]), matched, zero_filled

def current_position():
    positions = mt5.positions_get(symbol=SYMBOL)
    return positions[0] if positions else None

def close_position(ticket, pos_type, volume):
    req = {
        "action": mt5.TRADE_ACTION_DEAL,
        "position": ticket,
        "symbol": SYMBOL,
        "type": mt5.ORDER_TYPE_SELL if pos_type == mt5.ORDER_TYPE_BUY else mt5.ORDER_TYPE_BUY,
        "volume": volume,
        "price": mt5.symbol_info_tick(SYMBOL).bid if pos_type == mt5.ORDER_TYPE_BUY else mt5.symbol_info_tick(SYMBOL).ask,
        "deviation": SLIPPAGE,
        "magic": MAGIC,
        "comment": "Close position"
    }
    return mt5.order_send(req)

def open_position(direction, lot, sl=None, tp=None):
    tick = mt5.symbol_info_tick(SYMBOL)
    price = tick.ask if direction == "BUY" else tick.bid
    req = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": SYMBOL,
        "type": mt5.ORDER_TYPE_BUY if direction == "BUY" else mt5.ORDER_TYPE_SELL,
        "volume": lot,
        "price": price,
        "deviation": SLIPPAGE,
        "magic": MAGIC,
        "comment": "Open trade"
    }
    if sl: req["sl"] = sl
    if tp: req["tp"] = tp
    return mt5.order_send(req)

def dynamic_lot(equity):
    return round(max(0.01, equity / 10000), 2)

def calc_sl_tp(price, atr):
    sl = price - 2 * atr if atr else None
    tp = price + 4 * atr if atr else None
    return sl, tp

# === Główna pętla ===
def main():
    if not ensure_mt5_ready():
        raise RuntimeError("MT5 not ready. Start MT5 and login.")
    model = PPO.load(MODEL_PATH)
    expected_dim = int(model.observation_space.shape[0])

    with open(VECNORM_PATH, 'rb') as f:
        vecnorm = pickle.load(f)
    vecnorm.training = False
    vecnorm.norm_reward = False

    Path('paper_demo').mkdir(parents=True, exist_ok=True)
    csv = Path('paper_demo/live_decisions.csv')
    if not csv.exists():
        csv.write_text('time_utc,price,action_id,action_label,equity,lot,sl,tp,retcode,matched_features,zero_filled\n', encoding='utf-8')

    last_ts = None
    hb_t = time.time()

    while True:
        bars = get_last_bars(SYMBOL, TF, n=WINDOW + 800)
        if bars is None or len(bars) < WINDOW + 200:
            time.sleep(5)
            continue
        feat = add_features_incremental(bars)
        if len(feat) < WINDOW:
            time.sleep(5)
            continue
        cur_ts = feat['time'].iloc[-1]
        if last_ts is not None and cur_ts == last_ts:
            time.sleep(2)
            continue

        obs, matched, zero_filled = build_obs(feat, expected_dim)
        obs = vecnorm.normalize_obs(obs.reshape(1, -1)).reshape(-1)
        action, _ = model.predict(obs, deterministic=True)
        decision = {0: 'SHORT', 1: 'FLAT', 2: 'LONG'}[int(action)]
        price = float(feat['close'].iloc[-1])
        atr = float(feat['atr14'].iloc[-1]) if 'atr14' in feat.columns else None

        equity = mt5.account_info().equity
        lot = dynamic_lot(equity)
        sl, tp = calc_sl_tp(price, atr)
        retcode = None

        if not in_trade_hours(cur_ts):
            logging.info("Outside trade hours – skipping execution.")
        elif equity < MIN_EQUITY * mt5.account_info().balance:
            logging.info(f"Equity too low ({equity:.2f}) – skipping execution.")
        else:
            pos = current_position()
            if int(action) == 1:
                if pos:
                    res = close_position(pos.ticket, pos.type, pos.volume)
                    retcode = res.retcode
            else:
                desired = "BUY" if int(action) == 2 else "SELL"
                if not pos or (pos.type == mt5.ORDER_TYPE_BUY and desired == "SELL") or (pos.type == mt5.ORDER_TYPE_SELL and desired == "BUY"):
                    if pos:
                        close_position(pos.ticket, pos.type, pos.volume)
                    res = open_position(desired, lot, sl, tp)
                    retcode = res.retcode

        with open(csv, 'a', encoding='utf-8') as f:
            f.write(f"{cur_ts},{price:.5f},{int(action)},{decision},{equity:.2f},{lot:.2f},{sl},{tp},{retcode},{matched},{zero_filled}\n")

        last_ts = cur_ts
        if time.time() - hb_t > 600:
            logging.info(f"[HB] {SYMBOL} {TF_NAME} last_ts={cur_ts} price={price:.2f}")
            hb_t = time.time()
        time.sleep(30)

    mt5.shutdown()

if __name__ == '__main__':
    main()