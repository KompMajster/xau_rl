# save_gpr_cache.py
import pandas as pd
from pathlib import Path
import requests
import io

# Źródło CSV (benchmark GPR, miesięczny) – publiczny plik z witryny autorów:
URL = "https://www.matteoiacoviello.com/gpr_files/GPR.csv"

def main():
    r = requests.get(URL, timeout=30)
    r.raise_for_status()
    # Oryginalny CSV ma nagłówki 'date' i 'GPR' lub podobne – normalizujemy do (date,gpr)
    df = pd.read_csv(io.StringIO(r.text))
    # Ujednolicenie nazw kolumn:
    cols = {c.lower(): c for c in df.columns}
    # próbujemy znaleźć właściwe kolumny bez względu na wielkość liter
    date_col = [c for c in df.columns if c.lower() == 'date'][0]
    gpr_col  = [c for c in df.columns if c.lower() in ('gpr','gpr_index','value')][0]
    out = pd.DataFrame({
        'date': pd.to_datetime(df[date_col]).dt.tz_localize('UTC').dt.normalize(),
        'gpr': pd.to_numeric(df[gpr_col], errors='coerce')
    }).dropna().sort_values('date')
    out['date'] = out['date'].dt.strftime('%Y-%m-%d')

    path = Path("external/gpr"); path.mkdir(parents=True, exist_ok=True)
    out_path = path / "gpr.csv"
    out.to_csv(out_path, index=False)
    print(f"Saved GPR -> {out_path} ({len(out)} rows)")

if __name__ == "__main__":
    main()