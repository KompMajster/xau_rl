# -*- coding: utf-8 -*-
"""
save_te_calendar_cache.py
Pobiera kalendarz makro z Trading Economics i zapisuje cache do external/calendar_us.csv
Zmienna środowiskowa: TE_API_KEY=<Twój_klucz>
"""

from __future__ import annotations
import os, sys, csv
from pathlib import Path
from datetime import datetime, timedelta, timezone
import requests
import pandas as pd

# Domyślny zakres: od dziś-7 dni do dziś+21 dni (żeby objąć zdarzenia przed i po)
LOOKBACK_DAYS = int(os.getenv("TE_LOOKBACK_DAYS", "7"))
LOOKAHEAD_DAYS = int(os.getenv("TE_LOOKAHEAD_DAYS", "21"))
COUNTRY = os.getenv("TE_COUNTRY", "United States")

def iso_date(d: datetime) -> str:
    return d.strftime("%Y-%m-%d")

def fetch_te_calendar(api_key: str, country: str, start_date: str, end_date: str) -> pd.DataFrame:
    """
    API docs: https://docs.tradingeconomics.com/economic_calendar/
    Endpoint: GET /calendar/{start}/{end}?country=...&c=APIKEY
    """
    base = f"https://api.tradingeconomics.com/calendar/{start_date}/{end_date}"
    params = {"country": country, "c": api_key}
    r = requests.get(base, params=params, timeout=40)
    r.raise_for_status()
    data = r.json()

    rows = []
    for it in data:
        # Pola w TE bywają różne zależnie od endpointu — ujednolicamy
        ts = it.get("Date", it.get("DateUtc") or it.get("date"))
        if not ts:
            continue
        try:
            ts_utc = pd.to_datetime(ts, utc=True)
        except Exception:
            # czasami API zwraca bez Z — wymuś UTC
            ts_utc = pd.to_datetime(ts).tz_localize("UTC")
        rows.append({
            "time_utc" : ts_utc,
            "country"  : it.get("Country") or "",
            "event"    : it.get("Event") or it.get("Category") or "",
            "actual"   : it.get("Actual") if it.get("Actual") not in (None, "") else "",
            "previous" : it.get("Previous") if it.get("Previous") not in (None, "") else "",
            "forecast" : it.get("Forecast") if it.get("Forecast") not in (None, "") else "",
            # importance: TE zwykle zwraca 1..3 lub string; rzutujemy na int (brak -> 0)
            "importance": int(it.get("ImportanceValue", it.get("Importance", 0)) or 0),
        })

    df = pd.DataFrame(rows)
    if df.empty:
        return df
    # Normalizacja i sort
    df = df.sort_values("time_utc").reset_index(drop=True)
    return df

def main():
    api_key = os.getenv("TE_API_KEY")
    if not api_key:
        print("Brak TE_API_KEY. Ustaw zmienną środowiskową TE_API_KEY i uruchom ponownie.", file=sys.stderr)
        sys.exit(2)

    now = datetime.now(timezone.utc)
    start = now - timedelta(days=LOOKBACK_DAYS)
    end   = now + timedelta(days=LOOKAHEAD_DAYS)

    df = fetch_te_calendar(api_key, COUNTRY, iso_date(start), iso_date(end))
    out_dir = Path("external"); out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "calendar_us.csv"

    if df.empty:
        # jeśli API nic nie zwróciło — nie nadpisujemy istniejącego cache
        if out_path.exists():
            print(f"[warn] Pusta odpowiedź z TE. Zachowuję istniejący cache: {out_path}")
            sys.exit(0)
        else:
            print("[warn] Pusta odpowiedź z TE i brak wcześniejszego cache. Nic nie zapisano.")
            sys.exit(0)

    # Zapisz CSV w formacie zgodnym z features/calendar_features.py
    df_out = df.copy()
    # Upewnijmy się, że kolumny są w oczekiwanym zestawie
    df_out["time_utc"] = df_out["time_utc"].dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    cols = ["time_utc","country","event","actual","previous","forecast","importance"]
    df_out = df_out[cols]
    df_out.to_csv(out_path, index=False, quoting=csv.QUOTE_MINIMAL)
    print(f"Saved TE calendar -> {out_path} ({len(df_out)} rows)")

if __name__ == "__main__":
    main()