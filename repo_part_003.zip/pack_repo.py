#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pack_repo.py
Tworzy wieloczęściowe archiwa ZIP z repo/katalogu tak, aby każdy ZIP
miał maksymalnie zadany rozmiar (domyślnie 25 MB). Dodatkowo zapisuje
manifest JSON (mapowanie plików -> wolumen ZIP, rozmiary i SHA-256).
Opcjonalnie generuje "wersje tekstowe" ZIP-ów (Base64) do wklejenia w czacie.

Użycie (przykłady):
  python pack_repo.py --repo . --out out_zip --max-size-mb 25
  python pack_repo.py --repo . --out out_zip --max-size-mb 25 --code-only
  python pack_repo.py --repo . --out out_zip --emit-text --chunk-kb 700

Windows (PowerShell), ścieżki surowe:
  python pack_repo.py --repo C:\\proj --out C:\\backup\\out_zip --max-size-mb 25
"""

import os
import sys
import argparse
import hashlib
import json
import zipfile
from pathlib import Path
from datetime import datetime, timezone

# KATALOGI/PLIKI DO WYKLUCZENIA
EXCLUDE_DIRS = {
    '.git', '.hg', '.svn', '__pycache__', '.mypy_cache', '.ruff_cache',
    '.venv', 'venv', 'env', '.idea', '.vscode', 'node_modules',
    'logs', 'dist', 'build', '.cache', '.gradle'
}
EXCLUDE_FILES = {'.DS_Store', 'Thumbs.db'}

# Rozszerzenia „kodu/dokumentacji”
CODE_EXT = {
    '.py', '.ipynb', '.md', '.rst', '.txt', '.yaml', '.yml', '.toml',
    '.ini', '.cfg', '.ps1', '.bat', '.sh', '.csv', '.json'
}
# Pliki, które zwykle się dobrze kompresują
COMPRESSIBLE_EXT = CODE_EXT | {'.html', '.htm', '.css', '.js'}

def sha256_file(path: Path, buf: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        while True:
            b = f.read(buf)
            if not b:
                break
            h.update(b)
    return h.hexdigest()

def should_include(path: Path, repo_root: Path, code_only: bool, max_mb: float | None) -> bool:
    rel = path.relative_to(repo_root)
    # wyklucz wg katalogów po drodze
    for part in rel.parts[:-1]:
        if part in EXCLUDE_DIRS:
            return False
    # wyklucz pliki śmieciowe
    if path.name in EXCLUDE_FILES:
        return False
    # tylko kod?
    if code_only and path.suffix.lower() not in CODE_EXT:
        return False
    # limit rozmiaru pojedynczego pliku
    if max_mb is not None:
        try:
            if path.stat().st_size > int(max_mb * 1024 * 1024):
                return False
        except Exception:
            pass
    return True

def gather_files(repo_root: Path, code_only: bool, max_mb: float | None):
    files = []
    for p in repo_root.rglob('*'):
        if p.is_file() and should_include(p, repo_root, code_only, max_mb):
            files.append(p)
    # stabilna kolejność
    files.sort(key=lambda x: str(x.relative_to(repo_root)).lower())
    return files

def is_compressible(path: Path) -> bool:
    return path.suffix.lower() in COMPRESSIBLE_EXT

def estimate_zipped_size(path: Path) -> int:
    """
    Heurystyczny upper-bound rozmiaru wpisu w ZIP:
    - tekst/dane: ~60% lub (rozmiar - 2 KB) + 512 B
    - binarki: rozmiar + 512 B
    """
    try:
        sz = path.stat().st_size
    except Exception:
        sz = 0
    if is_compressible(path):
        est = max(int(sz * 0.60), sz - 2048)
        est = max(est, 0)
        return est + 512
    else:
        return sz + 512

def open_new_zip(out_dir: Path, vol_idx: int, compresslevel: int):
    zpath = out_dir / f"repo_part_{vol_idx:03d}.zip"
    zf = zipfile.ZipFile(
        zpath, mode='w',
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=max(0, min(9, int(compresslevel)))
    )
    return zf, zpath

def main():
    ap = argparse.ArgumentParser(description="Wieloczęściowy ZIP z repo/katalogu (limit rozmiaru wolumenu).")
    ap.add_argument('--repo', required=True, help='Ścieżka do repo/katalogu')
    ap.add_argument('--out', required=True, help='Folder wyjściowy na ZIP-y i manifest')
    ap.add_argument('--max-size-mb', type=float, default=25.0, help='Maksymalny rozmiar jednego ZIP-a (MB)')
    ap.add_argument('--code-only', action='store_true', help='Pakuj tylko pliki kodu/dokumentacji')
    ap.add_argument('--max-file-size-mb', type=float, default=None, help='Pomiń pliki > X MB')
    ap.add_argument('--compress-level', type=int, default=6, help='Poziom kompresji deflate (0-9)')
    ap.add_argument('--emit-text', action='store_true', help='Zapisz też wersje tekstowe ZIP-ów (Base64)')
    ap.add_argument('--chunk-kb', type=int, default=700, help='Rozmiar porcji tekstowych (KB), gdy --emit-text')
    args = ap.parse_args()

    repo_root = Path(args.repo).resolve()
    out_dir = Path(args.out).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    limit = int(args.max_size_mb * 1024 * 1024)
    if limit < 5 * 1024 * 1024:
        print("[WARN] Ustawiasz bardzo niski limit; rozważ >= 5 MB.", file=sys.stderr)

    print(f"[INFO] repo={repo_root}")
    print(f"[INFO] out ={out_dir}")
    print(f"[INFO] max ZIP size = {args.max_size_mb:.2f} MB")

    files = gather_files(repo_root, code_only=args.code_only, max_mb=args.max_file_size_mb)
    if not files:
        print("[ERROR] Brak plików do spakowania po filtrach.", file=sys.stderr)
        sys.exit(2)

    manifest = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "repo_root": str(repo_root),
        "max_zip_size_mb": args.max_size_mb,
        "volumes": [],  # metadane wolumenów
        "files": []     # pliki: relpath, size, sha256, volume_index
    }

    volume_idx = 1
    current_predicted = 0
    safety = 64 * 1024  # margines na central directory itp.

    zf, zpath = open_new_zip(out_dir, volume_idx, args.compress_level)
    volume_meta = {
        "index": volume_idx,
        "zip_name": zpath.name,
        "files": []
    }

    for f in files:
        rel = str(f.relative_to(repo_root)).replace('\\', '/')
        f_size = f.stat().st_size
        if f_size > limit:
            print(f"[ERROR] Plik '{rel}' ({f_size} B) > limit wolumenu {limit} B. Przerwano.", file=sys.stderr)
            zf.close()
            sys.exit(3)

        est = estimate_zipped_size(f)
        if current_predicted + est + safety > limit:
            zf.close()
            manifest["volumes"].append(volume_meta)

            volume_idx += 1
            current_predicted = 0
            zf, zpath = open_new_zip(out_dir, volume_idx, args.compress_level)
            volume_meta = {
                "index": volume_idx,
                "zip_name": zpath.name,
                "files": []
            }

        zf.write(f, arcname=rel)

        sha = sha256_file(f)
        entry = {
            "relpath": rel,
            "size": f_size,
            "sha256": sha,
            "volume_index": volume_idx
        }
        manifest["files"].append(entry)
        volume_meta["files"].append(entry)
        current_predicted += est

    zf.close()
    manifest["volumes"].append(volume_meta)

    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
    print(f"[DONE] Utworzono {len(manifest['volumes'])} ZIP-ów. Manifest: {out_dir/'manifest.json'}")

    if args.emit_text:
        import base64

        def split_text(s: str, chunk_chars: int):
            for i in range(0, len(s), chunk_chars):
                yield s[i:i+chunk_chars]

        chunk_chars = max(4_000, args.chunk_kb * 1024)
        for vol in manifest["volumes"]:
            zip_file = out_dir / vol["zip_name"]
            data = zip_file.read_bytes()
            b64 = base64.b64encode(data).decode('ascii')

            header = {
                "format": "ZIP-B64-VOLUME",
                "zip_name": zip_file.name,
                "zip_size_bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest()
            }
            parts = list(split_text(b64, chunk_chars))
            if len(parts) == 1:
                txt_name = zip_file.with_suffix('.txt')
                txt_name.write_text(json.dumps(header) + "\n\n" + b64 + "\n", encoding='utf-8')
                print(f"[TXT] {txt_name.name} (1 część)")
            else:
                for i, part in enumerate(parts, start=1):
                    hdr = header | {"part": i, "total": len(parts)}
                    txt_name = out_dir / f"{zip_file.stem}_part{i:02d}.txt"
                    txt_name.write_text(json.dumps(hdr) + "\n\n" + part + "\n", encoding='utf-8')
                print(f"[TXT] {zip_file.stem}_partXX.txt (części: {len(parts)})")

if __name__ == '__main__':
    main()